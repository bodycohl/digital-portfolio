import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.util.TreeMap;

/**
 * Contains all methods used to manipulate a message with the Affine Cipher.
 * 
 * @author Hailey Bodycoat
 */
public class Affine {
	
	/**
	 * Encrypts a file.
	 * 
	 * @param pathName - path of file that will be encrypted
	 * @param outputName - path of file that will contain the encrypted message
	 * @param a - first key value
	 * @param b - second key value
	 * 
	 * @return boolean - true if the file is successfully encrypted and false otherwise
	 */
	public boolean affineEncrypt(String pathName, String outputName, int a, int b)
	{
		try 
		{
			// Read contents of file into a string
			File file = new File (pathName);

			StringBuilder encryptedText = new StringBuilder();
			StringBuilder text = new StringBuilder();
			String contents = "";
			
			BufferedReader reader = new BufferedReader(new FileReader(file));
			
			while ((contents = reader.readLine()) != null )
			{
				text.append(contents);
			}
			
			reader.close();
			
			// Loop through each character of the file and use the encryption formula
			for (int i = 0; i < text.length(); i++)
			{
				char character = text.charAt(i);
				
				// ' ' is needed to loop at the correct values in the ASCII table
				character = (char) ((a * (character - ' ') + b) % 128 + ' ');
				
				// Append to string
				encryptedText.append(character);
			}
			
			System.out.print("\nEncrypted Text: " + encryptedText);
			
			// Write encrypted text to given file path
			File outputFile = new File (outputName);
			
			BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile));
			writer.append(encryptedText);
				
			writer.close();
				
		} catch (IOException e)
		{
			return false;
		}
		
		return true;
	}
	
	/**
	 * Decrypts a file.
	 * 
	 * @param pathName - path of file containing the encrypted message
	 * @param outputName - path of file where the decrypted message will be stored
	 * @param a - first key value
	 * @param b - second key value
	 * 
	 * @return boolean - returns true if the file is successfully decrypted and false otherwise
	 */
	public boolean affineDecrypt(String pathName, String outputName, int a, int b)
	{
		// Read contents of file into a string
		try 
		{
			File file = new File (pathName);
			
			StringBuilder decryptedText = new StringBuilder();
			StringBuilder text = new StringBuilder();
			String contents = "";
			
			BufferedReader reader = new BufferedReader(new FileReader(file));
			
			while ((contents = reader.readLine()) != null )
			{
				text.append(contents);
			}
			
			reader.close();
			
			// Found modInverse function online at: https://www.tutorialspoint.com/java/math/biginteger_modinverse.htm
			BigInteger modInverse = BigInteger.valueOf(a).modInverse(BigInteger.valueOf(128));
			
			// Loop through each character of the file and use the decryption formula
			for (int i = 0; i < text.length(); i++)
			{
				char character = text.charAt(i);
				character = (char)((modInverse.intValue() * ((character - ' ') - b + 128)) % 128 + ' ');
							
				// Append to string
				decryptedText.append(character);
			}
						
			System.out.print("\nDecrypted Text: " + decryptedText);
						
			// Write decrypted text to given file path
			File outputFile = new File (outputName);
						
			BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile));
			writer.append(decryptedText);
							
			writer.close();
			
		} catch (IOException e)
		{
			return false;
		}
		
		return true;
	}
	
	/**
	 * Attempts to find the correct key-value pair used to encrypt the message and then decipher the message.
	 * 
	 * @param pathName - path of file containing encrypted message
	 * @param outputName - path of file where decrypted message will be stored
	 * @param dictionary - dictionary file to look up valid words
	 * 
	 * @return String - returns the correctly formatted string with key-value pair and output
	 */  
	public void affineDecipher (String pathName, String outputName, String dictionaryName)
	{
		int firstKey = 0;		// first key
		int secondKey = 0;		// second key
		
		StringBuilder dictionaryWords = new StringBuilder();
		StringBuilder text = new StringBuilder();
		StringBuilder decipheredText = new StringBuilder();
		
		TreeMap <Integer, StringBuilder> maxWords = new TreeMap <Integer, StringBuilder>();
		
		// Open dictionary file and read it into a string
		try {
			File dictionaryFile = new File (dictionaryName);
			String contents = "";
						
			BufferedReader reader = new BufferedReader(new FileReader(dictionaryFile));
			
			while ((contents = reader.readLine()) != null)
			{
				dictionaryWords.append(contents);
				dictionaryWords.append("\n");
			}
			
			reader.close();

		} catch (FileNotFoundException e) {
			
			System.out.println("Not a valid dictionary file.");
			
		} catch (IOException e) {

			e.printStackTrace();
		}
		
		// Attempt to decipher given file
		try 
		{
			// Get the contents of the encrypted file
			File file = new File (pathName);
			String contents = "";
			
			BufferedReader reader = new BufferedReader(new FileReader(file));
			
			while ((contents = reader.readLine()) != null )
			{
				text.append(contents);
			}
			
			// FirstKey
			for (int i = 0; i < 128; i++)
			{
				// SecondKey
				for (int j = 0; j < 128; j++)
				{
					StringBuilder attemptDecipher = new StringBuilder();
					
					firstKey = i;
					secondKey = j;
					
					// Add if valid key
					if (checkValidity(firstKey))
					{
						// Decryption formula
						BigInteger inverse = BigInteger.valueOf(firstKey).modInverse(BigInteger.valueOf(128));
						
						for (int k = 0; k < text.length(); k++)
						{
							char character = text.charAt(k);
							character = (char)((inverse.intValue() * ((character - ' ') - secondKey + 128)) % 128 + ' ');
										
							attemptDecipher.append(character);
						}
						
						// Split by words
						String words[] = attemptDecipher.toString().split(" ");
						int wordsFound = 0;		// number of words in string
						
						for (int n = 0; n < words.length; n++)
						{
							if (dictionaryWords.toString().contains(words[n]))
							{
								wordsFound++;
							}
						}
						
						// Append keys, a space, new line and DECRYPTED MESSAGE for formatting
						attemptDecipher.insert(0, firstKey);
						
						if (firstKey > 10 && firstKey < 100)
						{
							attemptDecipher.insert(2, " ");
							attemptDecipher.insert(3, secondKey);
							
							if (secondKey > 10 && secondKey < 100)
							{
								attemptDecipher.insert(5, "\n");
								attemptDecipher.insert(6, "DECRYPTED MESSAGE: ");
								
							} else if (secondKey > 100)
							{
								attemptDecipher.insert(6, "\n");
								attemptDecipher.insert(7, "DECRYPTED MESSAGE: ");
								
							} else {
								
								attemptDecipher.insert(4, "\n");
								attemptDecipher.insert(5, "DECRYPTED MESSAGE: ");
							}
							
						} else if (firstKey > 100)
						{
							attemptDecipher.insert(3, " ");
							attemptDecipher.insert(4, secondKey);
							
							if (secondKey > 10 && secondKey < 100)
							{
								attemptDecipher.insert(6, "\n");
								attemptDecipher.insert(7, "DECRYPTED MESSAGE: ");
								
							} else if (secondKey > 100)
							{
								attemptDecipher.insert(7, "\n");
								attemptDecipher.insert(8, "DECRYPTED MESSAGE: ");
								
							} else {
								
								attemptDecipher.insert(5, "\n");
								attemptDecipher.insert(6, "DECRYPTED MESSAGE: ");
							}
							
						} else
						{
							attemptDecipher.insert(1, " ");
							attemptDecipher.insert(2, secondKey);
							
							if (secondKey > 10 && secondKey < 100)
							{
								attemptDecipher.insert(4, "\n");
								attemptDecipher.insert(5, "DECRYPTED MESSAGE: ");
								
							} else if (secondKey > 100)
							{
								attemptDecipher.insert(5, "\n");
								attemptDecipher.insert(6, "DECRYPTED MESSAGE: ");
							}
							else {
								
								attemptDecipher.insert(3, "\n");
								attemptDecipher.insert(4, "DECRYPTED MESSAGE: ");
							}
						}
						
						// Add to tree map <wordsFound, attemptDecipher>
						maxWords.put(wordsFound, attemptDecipher);
					}
				}
			}
			
			System.out.println();

			// Print the entry with the greatest words
			decipheredText = maxWords.lastEntry().getValue();
			System.out.println (decipheredText);
			
			// Write the attempted decipher to the given file
			File outputFile = new File (outputName);
			
			BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile));
			writer.append(decipheredText);
							
			writer.close();
			
		} catch (IOException e)
		{
			System.out.println("Unable to decipher the file.");
		}
	}
	
	/**
	 * Checks the validity of a and b as a key-value pair.
	 * Checks if a and m are co-primes, verifying that there is a multiplicative inverse.
	 * 
	 * @param a - first value (int)
	 * @param b - second value (int)
	 * @return boolean - true if the pair is valid and false otherwise
	 */
	public boolean checkValidity(int a)
	{
		int m = 128;
		int temp = -1;
		
		while (temp != 0)
		{
			temp = a % m;
			a = m;
			m = temp;
		}
		
		if (a == 1)
		{
			return true;
		} else {
			return false;
		}
	}

}
