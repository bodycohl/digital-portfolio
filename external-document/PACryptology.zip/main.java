import java.util.Scanner;

/**
 * Driver for Affine Cipher Utility Program.
 * 
 * @author Hailey Bodycoat
 */
public class main 
{
	public static void main (String[] args)
	{
		int entry;
		int a;
		int b;
		String pathName;
		String outputFileName;
		String dictionaryName;
		
		Scanner scanner = new Scanner (System.in);
		Affine cipherMethods = new Affine();
		
		System.out.println("Affine Cipher Utility Program\n");
		System.out.println ("Program Options: \n 1. Encryption - Encrypt a plaintext file to a ciphertext file with given keys\n 2. Decryption - Decrypt a ciphertext file to a plaintext file with given keys\n 3. Decipher - Given a ciphertext file, attempts to find the keys used to encrypt it and decrypts using the best keys found\n");
		System.out.print ("Enter the number of the desired option: ");
		
		entry = scanner.nextInt();
		
		switch (entry)
		{
			case 1:
				System.out.println("\nEncryption\n");
				
				System.out.print("Please enter the path of the file that will be encrypted: ");
				pathName = scanner.next();
				
				System.out.print("Please enter the path of the file that will contain the encrypted message: ");
				outputFileName = scanner.next();
				
				System.out.print("Please enter the first value for the key-value pair (a): ");
				a = scanner.nextInt();
				
				System.out.print("Please enter the second value for the key-value pair (b): ");
				b = scanner.nextInt();
				
				if (cipherMethods.checkValidity(a))
				{
					if (cipherMethods.affineEncrypt(pathName, outputFileName, a, b))
					{
						System.out.println("\nSuccess! The file has been encrypted.");
						
					} else {
						
						System.out.println("\nFailure. Something went wrong when attempting in encrypt the file.");
					}
					
				} else {
					
					System.out.println("\nThe key pair {" + a + "} {" + b + "} is invalid, please select another key.");
				}
				
				break;
			case 2:
				System.out.println("\nDecryption\n");
				
				System.out.print("Please enter the path of the encrypted file: ");
				pathName = scanner.next();
				
				System.out.print("Please enter the path of the file that will contain the decrypted message: ");
				outputFileName = scanner.next();
				
				System.out.print("Please enter the first value for the key-value pair (a): ");
				a = scanner.nextInt();
				
				System.out.print("Please enter the second value for the key-value pair (b): ");
				b = scanner.nextInt();
				
				if (cipherMethods.checkValidity(a))
				{
					if (cipherMethods.affineDecrypt(pathName, outputFileName, a, b))
					{
						System.out.println("\nSuccess! The file has been decrypted.");
					} else {
						System.out.println("\nFailure. Something went wrong when attempting in decrypt the file.");
					}
					
				} else {
					
					System.out.println("\nThe key pair {" + a + "} {" + b + "} is invalid, please select another key.");
				}
				break;
			case 3:
				System.out.println("\nDecipher\n");
				
				System.out.print("Please enter the path of the encrypted file: ");
				pathName = scanner.next();
				
				System.out.print("Please enter the path of the file that will contain the deciphered message: ");
				outputFileName = scanner.next();
				
				System.out.print("Please enter the path of the dictionary file that will be used to attempt to decrypt: ");
				dictionaryName = scanner.next();
				
				cipherMethods.affineDecipher(pathName, outputFileName, dictionaryName);

				break;
			default:
				
				System.out.println("\nThis is an invalid option number.");
				System.out.println("Please choose from on of the following: \n");
				System.out.println ("Program Options: \n 1. Encrypt\n 2. Decrypt\n 3. Dechiper\n");
				break;
		}
		
	}

}
